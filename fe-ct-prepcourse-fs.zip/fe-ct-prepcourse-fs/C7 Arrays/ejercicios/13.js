function filtrarNumerosPares(array) {
   // Convierte a mayúsculas todos los strings del array.
   const resultado = array.map((elemento) => elemento.toUpperCase());
   // Retorna el arreglo resultante.
   return resultado;
 }
 
 module.exports = convertirStringAMayusculas;
