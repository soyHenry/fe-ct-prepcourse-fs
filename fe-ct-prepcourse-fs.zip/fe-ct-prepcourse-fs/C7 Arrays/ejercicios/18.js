function promedioResultadosTest(resultadosTest) {
  // Itera sobre los elementos del arreglo resultadosTest y devuelve el promedio de las notas.
  // Tu código:
  if (!resultadosTest || resultadosTest.length === 0) {
    return 0; // Return 0 if the array is empty or null
  }

  const sum = resultadosTest.reduce((acc, nota) => acc + nota, 0);
  const average = sum / resultadosTest.length;
  return average;
}

module.exports = promedioResultadosTest;
