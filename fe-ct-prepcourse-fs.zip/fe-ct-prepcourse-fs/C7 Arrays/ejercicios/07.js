function ordenarArray(array) {
   // Ordena los elementos del arreglo array de menor a mayor.
  // Devuelve el arreglo resultante.
  // Tu código:
  return array.sort((a, b) => a - b);
  
}

module.exports = ordenarArray;
