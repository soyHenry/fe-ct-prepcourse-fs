function agregarItemAlComienzoDelArray(array, elemento) {
 // Agrega el "elemento" al comienzo del arreglo recibido.
 array.unshift(elemento);
 // Retorna el arreglo.
 return array;
}

module.exports = agregarItemAlComienzoDelArray;
