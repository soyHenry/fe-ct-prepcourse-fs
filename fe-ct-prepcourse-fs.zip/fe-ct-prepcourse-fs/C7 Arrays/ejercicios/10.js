function obtenerPrimerStringLargo(array) {
  for (const str of array) {
    if (str.length > 5) {
      return str;
    }
  }
  return null; // Return null if no string with more than 5 characters is found.
}

module.exports = obtenerPrimerStringLargo;
