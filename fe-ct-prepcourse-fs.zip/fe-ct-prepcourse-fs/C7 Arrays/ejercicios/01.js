function devolverPrimerElemento(array) {
  // Retornar el primer elemento del arreglo recibido.
  // Tu código:
  return array[0];
}

module.exports = devolverPrimerElemento;
