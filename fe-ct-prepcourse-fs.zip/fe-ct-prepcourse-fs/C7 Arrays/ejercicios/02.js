function devolverUltimoElemento(array) {
  // Retornar el último elemento del arreglo recibido.
  // Tu código:
  if (array.length === 0) {
    return "El arreglo está vacío.";
  }
  return array[array.length - 1];

}

module.exports = devolverUltimoElemento;
