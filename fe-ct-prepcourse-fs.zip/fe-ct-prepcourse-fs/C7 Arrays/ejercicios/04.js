function agregarItemAlFinalDelArray(array, elemento) {
  // Agrega el "elemento" al final del arreglo recibido.
  // Retorna el arreglo.
  // Tu código:
  // Agrega el "elemento" al final del arreglo recibido.
  array.push(elemento);
  // Retorna el arreglo.
  return array;
}

module.exports = agregarItemAlFinalDelArray;
