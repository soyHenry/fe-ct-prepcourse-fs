function obtenerLargoDelArray(array) {
  // Retornar la longitud del arreglo recibido.
  // Tu código:
  return array.length;
}

module.exports = obtenerLargoDelArray;
