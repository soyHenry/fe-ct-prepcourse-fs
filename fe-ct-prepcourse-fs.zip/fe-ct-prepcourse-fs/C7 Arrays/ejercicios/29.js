function encontrarNumeroFaltante(numeros) {
  // La función recibe un argumento "numeros" correspondiente a un array de números.
  // Encuentra el número faltante en una secuencia de números enteros consecutivos
  // y retórnalo.
  // Devuelve null si el aray es vacío o si no hay números faltantes.
  // Tu código:
  if (numeros.length === 0) {
    return null; // Devuelve null si el array es vacío
  }

  // Calcula la suma total esperada de la secuencia
  const n = numeros.length + 1;
  const sumaEsperada = (n * (n + 1)) / 2;

  // Calcula la suma real de los números en el array
  const sumaReal = numeros.reduce((acc, num) => acc + num, 0);

  // Encuentra el número faltante
  const numeroFaltante = sumaEsperada - sumaReal;

  if (numeroFaltante >= 1 && numeroFaltante <= n) {
    return numeroFaltante; // Devuelve el número faltante
  } else {
    return null; // Devuelve null si no hay números faltantes
  }
}

module.exports = encontrarNumeroFaltante;