function invertirArray(array) {
  // Utilizamos el método reverse() para invertir el arreglo.
  return array.reverse();
}

module.exports = invertirArray;
