![HenryLogo](../assets/logoBannerHenry.png)

# **HOMEWORK 01 | INSTALACIÓN DE HERRAMIENTAS**

## **📌 LINKS IMPORTANTES**

---

</br >

### **📍 NODE**

Recuerda que debes descargar la versión **LTS** de Node.JS, ya que la versión más actual puede tener incompatibilidades.

[**LINK DE DESCARGA**](https://nodejs.org/es/)

---

</br >

### **📍 GIT**

Recuerda que si tu sistema operativo en **Linux** ya tienes GIT instalado por defecto. Si tu sistema operativo es **Windows** puedes descargarlo en el siguiente link:

[**LINK DE DESCARGA**](https://gitforwindows.org/)

---

</br >

### **📍 SLACK**

No es obligatorio que descargues este aplicación en tu computadora, pero te será más sencillo poder comunicarte con la comunidad.

[**LINK DE DESCARGA**](https://slack.com/intl/es-ar/downloads/windows)

---

</br >

### **📍 GITHUB DESKTOP**

No es necesario que descargues esta aplicación para utilizar GitHub. Simplemente puedes utilizar la versión web. Pero si quieres acelerar los procesos te dejamos el link de desacarga!

[**LINK DE DESCARGA**](https://desktop.github.com/)
