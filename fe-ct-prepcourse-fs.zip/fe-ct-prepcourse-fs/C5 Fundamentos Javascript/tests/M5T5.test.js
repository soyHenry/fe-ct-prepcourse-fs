const nuevaMultiplicacion = require("../ejercicios/05");

test('Debe ser la multiplicación correcta', function () {
  expect(nuevaMultiplicacion).toBe(true);
});