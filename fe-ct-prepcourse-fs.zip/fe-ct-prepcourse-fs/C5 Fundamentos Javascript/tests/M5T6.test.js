const nuevoModulo = require("../ejercicios/06");

test('Debe ser el resultado correcto del módulo', function () {
  expect(nuevoModulo).toBe(true);
});