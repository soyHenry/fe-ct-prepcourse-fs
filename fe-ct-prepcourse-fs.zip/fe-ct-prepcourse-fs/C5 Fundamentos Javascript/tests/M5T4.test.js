const nuevaResta = require("../ejercicios/04");

test('Debe ser la resta correcta', function () {
  expect(nuevaResta).toBe(true);
});