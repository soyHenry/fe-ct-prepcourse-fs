const nuevoString = require('../ejercicios/01');

test('Debe ser un string', function () {
  expect(typeof nuevoString).toBe('string');
});
