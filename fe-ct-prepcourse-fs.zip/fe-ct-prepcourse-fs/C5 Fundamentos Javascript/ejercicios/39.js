// ⛔️ Recuerda que debes utilizar el objeto global "Math".

function numeroRandom() {
  // Genera un número al azar entre 0 y 1 y retórnalo.
  // Tu código:
  
  return Math.random();
  
}

module.exports = numeroRandom;
