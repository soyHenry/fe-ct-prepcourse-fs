// Resuelve el siguiente problema matemático.
// Reemplaza el valor de null por el correspondiente.

const nuevoModulo = 21 % 5 === 1;

module.exports = nuevoModulo;
