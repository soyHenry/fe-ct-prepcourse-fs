// Resuelve el siguiente problema matemático.
// Reemplaza el valor de null por el correspondiente.

const nuevaMultiplicacion = 10 * 4 === 40;

module.exports = nuevaMultiplicacion;