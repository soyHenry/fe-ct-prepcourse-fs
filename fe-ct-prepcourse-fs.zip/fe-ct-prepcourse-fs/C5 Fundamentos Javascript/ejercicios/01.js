// Crea una variable de tipo string.
// Reemplaza el valor de null por el correspondiente.

const nuevoString = 'null';

module.exports = nuevoString;