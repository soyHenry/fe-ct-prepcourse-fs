function areaDelTriangulo(base, altura) {
  // Calcula el área de un triángulo y retorna el resultado.
  // Tu código:
  return base * altura;
}

module.exports = areaDelTriangulo;
