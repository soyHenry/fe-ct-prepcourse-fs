function esImpar(num) {
  // Retorna true si "num" es impar.
  // De lo contrario, retorna false.
  // Tu código:
  return num % 2 !== 0;
}

module.exports = esImpar;