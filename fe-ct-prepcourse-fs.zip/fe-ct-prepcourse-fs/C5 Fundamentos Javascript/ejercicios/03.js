// Crea una variable de tipo boolean.
// Reemplaza el valor de null por el correspondiente.

const nuevoBoolean =false;

module.exports = nuevoBoolean;