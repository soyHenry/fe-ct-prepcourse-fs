// Crea una variable de tipo number.
// Reemplaza el valor de null por el correspondiente.

const nuevoNumero = 42;

module.exports = nuevoNumero;