// Resuelve el siguiente problema matemático.
// Reemplaza el valor de null por el correspondiente.

const nuevaResta = 10 - 7 === 3;

module.exports = nuevaResta;