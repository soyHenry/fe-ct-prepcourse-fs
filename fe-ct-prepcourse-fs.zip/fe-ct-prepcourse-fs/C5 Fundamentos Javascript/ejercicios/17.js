function esPar(num) {
  // Retorna true si "num" es par.
  // De lo contrario, retorna false.
  // Tu código:
  return num % 2 === 0;
}

module.exports = esPar;
