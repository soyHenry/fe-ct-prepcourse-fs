function devolverString(string) {
  // La función recibe un argumento "string".
  // Debe retornar dicho string.
  // Tu código:
  return string;

}

module.exports = devolverString; 