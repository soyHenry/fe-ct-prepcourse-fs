function esFechaValida(fecha) {
  // La función recibe un argumento "fecha".
  // Comprueba si este corresponde a una fecha válida.
  // Si es así, retorna true, sino retorna false.
  // Tu código:
  const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
  if (!dateRegex.test(fecha)) {
    return false; // No cumple el formato AAAA-MM-DD
  }

  const [year, month, day] = fecha.split('-').map(Number);
  const isValidDate = (year > 0 && month >= 1 && month <= 12 && day >= 1 && day <= 31);

  if (!isValidDate) {
    return false; // No es una fecha válida
  }

  // Verificar febrero y los meses con 30 días
  if ((month === 2 && day > 29) || ((month === 4 || month === 6 || month === 9 || month === 11) && day > 30)) {
    return false; // Día inválido para el mes
  }

  // Año bisiesto
  if (month === 2 && day === 29) {
    if ((year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0)) {
      return true; // Es un año bisiesto
    } else {
      return false; // No es un año bisiesto
    }
  }

  return true; // Fecha válida
}

module.exports = esFechaValida;