function obtenerAreaRectangulo(alto, ancho) {
  // Retornar el área de un rectángulo teniendo su alto y ancho.
  // Tu código:
  return alto * ancho;
}

module.exports = obtenerAreaRectangulo;
