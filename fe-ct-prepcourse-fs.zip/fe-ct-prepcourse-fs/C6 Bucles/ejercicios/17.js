function colors(color) {
  // La función recibe un color. Retorna el string correspondiente:
  // En caso que el color recibido sea "blue"   --> "This is blue".
  // En caso que el color recibido sea "red"    --> "This is red".
  // En caso que el color recibido sea "green"  --> "This is green".
  // En caso que el color recibido sea "orange" --> "This is orange".
  // Si no es ninguno de esos colores           --> "Color not found".
  // PISTA: utilizar el statement SWITCH.
  // Tu código:
  switch (color) {
    case "blue":
      return "this is blue";
    case "red":
      return "this is red";
    case "green":
      return "this is green";
      case "orange":
      return "this is orange";
    default:
      return "color not found";
  }
}

module.exports = colors;
