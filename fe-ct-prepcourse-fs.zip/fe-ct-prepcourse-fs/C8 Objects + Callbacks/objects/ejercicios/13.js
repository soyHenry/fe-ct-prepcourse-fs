function eliminarPropiedad(objeto, propiedad) {
  // Verifica si la propiedad existe en el objeto
  if (objeto.hasOwnProperty(propiedad)) {
    // Elimina la propiedad
    delete objeto[propiedad];
  }
  // Retorna el objeto modificado
  return objeto;
}

module.exports = eliminarPropiedad;
