function actualizarPassword(objetoUsuario, nuevaPassword) {
  // Replace the stored password in the "password" property of "objetoUsuario".
  // The new password is received as a parameter.
  objetoUsuario.password = nuevaPassword;
  // Return the updated object.
  return objetoUsuario;
}

module.exports = actualizarPassword;
