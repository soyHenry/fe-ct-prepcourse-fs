function pasarUsuarioAPremium(objetoMuchosUsuarios) {
  // Itera sobre cada usuario en el arreglo
  for (const usuario of objetoMuchosUsuarios) {
    // Establece la propiedad "esPremium" en true
    usuario.esPremium = true;
  }
  // Retorna el arreglo modificado
  return objetoMuchosUsuarios;
}

module.exports = pasarUsuarioAPremium;
