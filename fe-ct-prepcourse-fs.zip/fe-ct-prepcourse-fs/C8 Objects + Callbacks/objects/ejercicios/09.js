function nuevoUsuario(nombre, email, password) {
  // Debes crear un nuevo objeto.
  // Este debe tener las propiedades: "nombre", "email" y "password" con sus respectivos valores.
  // Retorna el objeto creado.
  // Tu código:
  // Create a new user object
  const user = {
    nombre: nombre,
    email: email,
    password: password
  };

  // Return the created object
  return user;
}

module.exports = nuevoUsuario;
