function agregarAmigo(objetoUsuario, nuevoAmigo) {
  // Verificamos si el objetoUsuario tiene la propiedad "amigos" y si es un arreglo
  if (objetoUsuario.hasOwnProperty("amigos") && Array.isArray(objetoUsuario.amigos)) {
    // Agregamos el nuevoAmigo al final del arreglo de amigos
    objetoUsuario.amigos.push(nuevoAmigo);
  }
  // Retornamos el objeto actualizado
  return objetoUsuario;
}

module.exports = agregarAmigo;
